# User Interface

A simple website built to display user information.

## How to install

Clone this repo

    git clone https://github.com/Kiruxg/take-home-ui-exam.git

Install all dependencies

    npm i

Run the server

    npm run-script watch
